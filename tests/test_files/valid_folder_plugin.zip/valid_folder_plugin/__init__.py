bl_info = {
    "name": "ValidTestPlugin_in_folder",
    "author": "Christopher Winkelmann",
    "version": (0, 0, 1),
    "blender": (2, 80, 0),
    "location": "",
    "description": "Test plugin for Blender Addon Installer validation.",
    "warning": "",
    "wiki_url": "",
    "category": ""
}

print("Valid Test Plugin in Folder loaded ...")
